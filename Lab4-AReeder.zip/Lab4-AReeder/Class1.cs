﻿namespace Lab4_AReeder;

public class States
{
    public int StateID { get; set; }
    public string StateName { get; set; }
    public decimal Population { get; set; }
    public string StateFlag { get; set; }
    public string StateFlower { get; set; }
    public string StateBird { get; set; }
    public string StateColors { get; set; }
    public string LargestCities { get; set; }
    public string StateCapital { get; set; }
    public int MedianIncome { get; set; }
    public decimal ComputerJobPercentage { get; set; }

}

public class StatesExtra
{
    //initialize class connection string
    private readonly string _connectionString;

    public StateExtra(string connectionString)
    {
        _connectionString = connectionString;
    }

    public List<State> GetAllStates()
    {
        //declare list of states
        var states = new List<State>();
        try
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = "SELECT StateID, StateName, [Population(mil)], StateFlag, StateFlower, " +
                               "StateBird, StateColors, LargestCities, StateCapital, MedianIncome, ComputerJobPercentage " +
                               "FROM States";

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        states.Add(new State
                        {
                            StateID = reader.GetInt32(reader.GetOrdinal("StateID")),
                            StateName = reader.GetString(reader.GetOrdinal("StateName")),
                            Population = reader.GetDecimal(reader.GetOrdinal("Population(mil)")),
                            StateFlag = reader.GetString(reader.GetOrdinal("StateFlag")),
                            StateFlower = reader.IsDBNull(reader.GetOrdinal("StateFlower")) ? null : reader.GetString(reader.GetOrdinal("StateFlower")),
                            StateBird = reader.IsDBNull(reader.GetOrdinal("StateBird")) ? null : reader.GetString(reader.GetOrdinal("StateBird")),
                            StateColors = reader.IsDBNull(reader.GetOrdinal("StateColors")) ? null : reader.GetString(reader.GetOrdinal("StateColors")),
                            LargestCities = reader.GetString(reader.GetOrdinal("LargestCities")),
                            StateCapital = reader.GetString(reader.GetOrdinal("StateCapital")),
                            MedianIncome = reader.GetInt32(reader.GetOrdinal("MedianIncome")),
                            ComputerJobPercentage = reader.IsDBNull(reader.GetOrdinal("ComputerJobPercentage")) ? 0 : reader.GetInt32(reader.GetOrdinal("ComputerJobPercentage"))
                        });



                    }

                }

            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error getting states: {ex.Message}");
        }
        return states;


    }

    public void UpdateState(State state)
    {
        try
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = @"
                UPDATE States
                SET StateName = @StateName,
                    Population = @Population,
                    StateBird = @StateBird,
                    StateFlower = @StateFlower,
                    StateCapital = @StateCapital,
                    StateColors = @StateColors,
                    ComputerJobPercentage = @ComputerJobPercentage,
                    LargestCities = @LargestCities,
                    StateFlag = @StateFlag,
                    MedianIncome = @MedianIncome
                WHERE StateID = @StateID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StateName", state.StateName);
                    command.Parameters.AddWithValue("@Population", state.Population);
                    command.Parameters.AddWithValue("@StateBird", state.StateBird ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@StateFlower", state.StateFlower ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@StateCapital", state.StateCapital);
                    command.Parameters.AddWithValue("@StateColors", state.StateColors ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@ComputerJobPercentage", state.ComputerJobPercentage);
                    command.Parameters.AddWithValue("@LargestCities", state.LargestCities);
                    command.Parameters.AddWithValue("@StateFlag", state.StateFlag);
                    command.Parameters.AddWithValue("@MedianIncome", state.MedianIncome);
                    command.Parameters.AddWithValue("@StateID", state.StateID);

                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error updating state in database: {ex.Message}");
        }
    }
}
}